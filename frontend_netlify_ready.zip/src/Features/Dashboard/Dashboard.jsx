const Dashboard = () => {
    return (
      <div>
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Dashboard Page</h1>
      </div>
    );
  };
  
  export default Dashboard;
  