-- AlterTable
ALTER TABLE `postulacion` ADD COLUMN `fechaAprobacion` DATETIME(3) NULL,
    ADD COLUMN `fechaValidacion` DATETIME(3) NULL;
