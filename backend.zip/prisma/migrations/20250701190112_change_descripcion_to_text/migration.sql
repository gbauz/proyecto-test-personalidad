-- AlterTable
ALTER TABLE `personalidades` MODIFY `descripcion` TEXT NULL;
