-- This is an empty migration.

INSERT INTO Pregunta (pregunta, categoriaPreguntasId) VALUES 
    ("Cuando suena el teléfono, suelo correr para contestar primero.", 1),
    ("Cuando hago fila, suelo conversar con otras personas.", 1),
    ("En fiestas, interactúo con muchas personas, incluso extraños.", 1),
    ("Interactuar con extraños me llena de energía.", 1),
    ("Por lo general digo inmediatamente lo que pienso.", 1),
    ("Me considero una persona sociable.", 1)
    ;