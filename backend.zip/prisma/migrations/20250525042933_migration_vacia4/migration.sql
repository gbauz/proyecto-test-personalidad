-- This is an empty migration.

INSERT INTO Pregunta (pregunta, categoriaPreguntasId) VALUES 
    ("Me considero más observador que introspectivo.", 2),
    ("Estar en las nubes me parece peor que seguir una rutina.", 2),
    ("Me interesa más lo que es real que lo que es posible.", 2),
    ("Tiendo a ser más objetivo que especulativo.", 2),
    ("Prefiero a escritores que expresan claramente lo que piensan.", 2),
    ("Creo que los hechos hablan por sí mismos.", 2),
    ("Me parecen bastante fascinantes los visionarios y teóricos.", 2),
    ("El sentido común me parece por lo general confiable.", 2),
    ("A menudo creo que los niños no usan lo suficiente su imaginación.", 2),
    ("Soy una persona más práctica que fantasiosa.", 2),
    ("Suelo hablar más de particularidades que de generalidades.", 2);