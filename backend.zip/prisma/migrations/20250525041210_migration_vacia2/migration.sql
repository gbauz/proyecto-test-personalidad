-- This is an empty migration
INSERT INTO `Respuesta` (nombre, puntaje) VALUES
    ('Totalmente en desacuerdo', -2),
    ('En desacuerdo', -1),
    ('Ni de acuerdo ni en desacuerdo', 0),
    ('De acuerdo', 1),
    ('Totalmente de acuerdo', 2);